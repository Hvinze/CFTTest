from crhelper import CfnResource
import boto3
from botocore.exceptions import ClientError
import logging
import os
import json


# Retrieve the logger instance
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

helper = CfnResource(
    	json_logging=False,
	    log_level='DEBUG', 
	    boto_level='CRITICAL'
	)


@helper.create
def create_deployment_group(event,context):
    logger.info("Got Create Event...........")
    
    RegionName=event['ResourceProperties']['RegionName']
    ApplicationName=event['ResourceProperties']['ApplicationName']
    DeploymentGroupName=event['ResourceProperties']['DeploymentGroupName']
    DeploymentConfig=event['ResourceProperties']['DeploymentConfig']
    ServiceRoleArn=event['ResourceProperties']['ServiceRoleArn']
    ClusterName=event['ResourceProperties']['ClusterName']
    ServiceName=event['ResourceProperties']['ServiceName']
    TGProd=event['ResourceProperties']['TGProd']
    TGTest=event['ResourceProperties']['TGTest']
    ProdListener=event['ResourceProperties']['ProdListener']
    TestListener=event['ResourceProperties']['TestListener']
    TagName=event['ResourceProperties']['TagName']
    TagComponent=event['ResourceProperties']['TagComponent']
    
    cdclient = boto3.client('codedeploy',region_name=RegionName)
    
    #try:
    response = cdclient.create_deployment_group(
        applicationName=ApplicationName,
        deploymentGroupName=DeploymentGroupName,
        deploymentConfigName=DeploymentConfig,
        serviceRoleArn=ServiceRoleArn,
        autoRollbackConfiguration={
            'enabled': True,
            'events': [
                'DEPLOYMENT_FAILURE', 'DEPLOYMENT_STOP_ON_ALARM','DEPLOYMENT_STOP_ON_REQUEST',
            ]
        },
        deploymentStyle={
            'deploymentType': 'BLUE_GREEN',
            'deploymentOption': 'WITH_TRAFFIC_CONTROL'
        },
        blueGreenDeploymentConfiguration={
            'terminateBlueInstancesOnDeploymentSuccess': {
                'action': 'TERMINATE',
                'terminationWaitTimeInMinutes': 10
            },
            'deploymentReadyOption': {
                'actionOnTimeout': 'STOP_DEPLOYMENT',
                'waitTimeInMinutes': 5
            }
        },
        loadBalancerInfo={
            'targetGroupPairInfoList': [
                {
                    'targetGroups': [
                        {
                            'name': TGProd
                        },
                        {
                            'name': TGTest
                        }
                    ],
                    'prodTrafficRoute': {
                        'listenerArns': [
                            ProdListener
                        ]
                    },
                    'testTrafficRoute': {
                        'listenerArns': [
                            TestListener
                        ]
                    }
                },
            ]
        },
        ecsServices=[
            {
                'serviceName': ServiceName,
                'clusterName': ClusterName
            },
        ],
        tags=[
            {
                'Key': 'Name',
                'Value': TagName
            },
            {
                'Key': 'Component',
                'Value': TagComponent
            }
        ]
    )
    deployment_Group_Id = response['deploymentGroupId']
    print('Deployment Group for ECS is Successfully Created %s .' % (deployment_Group_Id))
    #except ClientError as e:
    #    print(e) 
    #return

@helper.update
def no_op(_, __):
    pass
   

@helper.delete
def delete_deployment_group(event,context):
    
    RegionName=event['ResourceProperties']['RegionName']
    ApplicationName=event['ResourceProperties']['ApplicationName']
    DeploymentGroupName=event['ResourceProperties']['DeploymentGroupName']
    client = boto3.client('codedeploy',region_name=RegionName)
    response = client.delete_deployment_group(
        applicationName=ApplicationName,
        deploymentGroupName=DeploymentGroupName
    )
    print(response)
    print('Deployment Group for ECS is Successfully Deleted')

def handler(event, context):
    helper(event, context)